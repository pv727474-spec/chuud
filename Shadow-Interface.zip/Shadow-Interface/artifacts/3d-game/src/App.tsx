import { useCallback, useEffect, useMemo, useRef, useState, type MutableRefObject, type PointerEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { KeyboardControls, Text, useKeyboardControls } from '@react-three/drei';
import * as THREE from 'three';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

enum Controls {
  forward = 'forward',
  back = 'back',
  left = 'left',
  right = 'right',
}

type Phase = 'intro' | 'explore' | 'house' | 'tower' | 'complete';
type Landmark = 'house' | 'tower';

const keyMap = [
  { name: Controls.forward, keys: ['ArrowUp', 'KeyW'] },
  { name: Controls.back, keys: ['ArrowDown', 'KeyS'] },
  { name: Controls.left, keys: ['ArrowLeft', 'KeyA'] },
  { name: Controls.right, keys: ['ArrowRight', 'KeyD'] },
];

const TREES = [
  [-18, -10, 1.05], [-21, -2, 0.8], [-18, 9, 1.2], [-13, -22, 1.15],
  [-9, -29, 0.72], [-2, -25, 1.32], [6, -20, 0.9], [18, -22, 1.28],
  [21, -10, 0.9], [18, 1, 1.3], [22, 10, 0.78], [-25, 18, 1.05],
  [-30, 4, 0.8], [28, -30, 1.1], [3, 9, 0.78], [13, -5, 0.84],
] as const;
const ROCKS = [
  [-3, 3, 0.9], [4, -3, 0.6], [-12, -3, 1.1], [12, -12, 0.9],
  [-17, -16, 0.65], [15, -35, 1.1], [-22, -30, 0.72], [26, -17, 0.55],
] as const;
const FIREFLIES = [
  [-4, 2.8, -5], [-2.4, 2.2, -8], [1.8, 2.5, -10], [4.5, 2.1, -13],
  [7, 2.6, -15], [10, 2.1, -19], [-5.5, 1.8, -12], [-10, 2.4, -15],
] as const;
const COLLIDERS = [
  { x: -8, z: -11, w: 4.4, d: 3.8 },
  { x: 10, z: -27, w: 2.3, d: 2.3 },
];

function Tree({ x, z, scale }: { x: number; z: number; scale: number }) {
  return (
    <group position={[x, 0, z]} scale={scale}>
      <mesh position={[0, 1.6, 0]} castShadow>
        <cylinderGeometry args={[0.22, 0.38, 3.2, 7]} />
        <meshStandardMaterial color="#201d26" roughness={1} />
      </mesh>
      <mesh position={[0, 3.1, 0]} castShadow>
        <coneGeometry args={[1.8, 3.9, 7]} />
        <meshStandardMaterial color="#152d32" roughness={0.95} />
      </mesh>
      <mesh position={[0, 4.55, 0]} castShadow>
        <coneGeometry args={[1.25, 3.1, 7]} />
        <meshStandardMaterial color="#1b3a3b" roughness={0.95} />
      </mesh>
    </group>
  );
}

function Rock({ x, z, scale }: { x: number; z: number; scale: number }) {
  return (
    <mesh position={[x, scale * 0.35, z]} scale={[scale * 1.3, scale, scale]} rotation={[0.1, scale, 0.08]} castShadow>
      <dodecahedronGeometry args={[1, 0]} />
      <meshStandardMaterial color="#303740" roughness={1} />
    </mesh>
  );
}

function House() {
  return (
    <group position={[-8, 0, -11]}>
      <mesh position={[0, 1.7, 0]} castShadow>
        <boxGeometry args={[4.2, 3.4, 3.4]} />
        <meshStandardMaterial color="#302d32" roughness={0.95} />
      </mesh>
      <mesh position={[0, 3.9, 0]} rotation={[0, Math.PI / 4, 0]} castShadow>
        <coneGeometry args={[3.05, 2.25, 4]} />
        <meshStandardMaterial color="#191d29" roughness={1} />
      </mesh>
      <mesh position={[0, 1.15, -1.73]}>
        <boxGeometry args={[0.85, 1.8, 0.08]} />
        <meshStandardMaterial color="#111722" roughness={1} />
      </mesh>
      <mesh position={[-1.2, 1.8, -1.74]}>
        <boxGeometry args={[0.65, 0.7, 0.08]} />
        <meshStandardMaterial color="#a7cbd0" emissive="#4b9faf" emissiveIntensity={0.2} />
      </mesh>
      <mesh position={[1.2, 1.8, -1.74]}>
        <boxGeometry args={[0.65, 0.7, 0.08]} />
        <meshStandardMaterial color="#0a111c" roughness={1} />
      </mesh>
      <Text position={[0, 5.8, 0]} fontSize={0.43} color="#9cafb3" anchorX="center" anchorY="middle">
        THE OLD HOUSE
      </Text>
    </group>
  );
}

function Tower() {
  return (
    <group position={[10, 0, -27]}>
      <mesh position={[0, 6, 0]} castShadow>
        <boxGeometry args={[2.2, 12, 2.2]} />
        <meshStandardMaterial color="#252b36" roughness={0.88} />
      </mesh>
      <mesh position={[0, 12.3, 0]} castShadow>
        <coneGeometry args={[2.1, 2.4, 4]} />
        <meshStandardMaterial color="#131a27" roughness={0.9} />
      </mesh>
      <mesh position={[0, 10.2, -1.15]}>
        <boxGeometry args={[0.7, 0.85, 0.08]} />
        <meshStandardMaterial color="#7bdff1" emissive="#39cbe6" emissiveIntensity={1.8} />
      </mesh>
      <mesh position={[0, 13.9, 0]}>
        <octahedronGeometry args={[0.95, 0]} />
        <meshStandardMaterial color="#a3f7ff" emissive="#28cdeb" emissiveIntensity={4} metalness={0.2} roughness={0.15} />
      </mesh>
      <pointLight position={[0, 13.9, 0]} color="#3fd8f1" intensity={4.2} distance={18} />
      <Text position={[0, 15.6, 0]} fontSize={0.43} color="#8bddea" anchorX="center" anchorY="middle">
        THE SIGNAL
      </Text>
    </group>
  );
}

function WebglFallback() {
  return (
    <div className="webgl-fallback" role="status">
      <div className="webgl-fallback-kicker">Shadow Valley / low signal</div>
      <h2>Graphics could not start</h2>
      <p>
        This browser or preview does not have an available WebGL context.
        Try the game in a hardware-accelerated browser to enter the valley.
      </p>
    </div>
  );
}

function Fireflies() {
  const refs = useRef<Array<THREE.Mesh | null>>([]);
  useFrame(({ clock }) => {
    refs.current.forEach((mesh, index) => {
      if (!mesh) return;
      mesh.position.y = FIREFLIES[index][1] + Math.sin(clock.elapsedTime * 1.4 + index) * 0.22;
      mesh.scale.setScalar(0.72 + Math.sin(clock.elapsedTime * 2 + index) * 0.18);
    });
  });
  return (
    <>
      {FIREFLIES.map(([x, y, z], index) => (
        <mesh key={`${x}-${z}`} ref={(node) => { refs.current[index] = node; }} position={[x, y, z]}>
          <sphereGeometry args={[0.09, 8, 8]} />
          <meshBasicMaterial color="#65ddf1" />
          {index % 2 === 0 && <pointLight color="#3ecce4" intensity={0.45} distance={4} />}
        </mesh>
      ))}
    </>
  );
}

function ValleyWorld() {
  return (
    <>
      <color attach="background" args={['#080d1a']} />
      <fog attach="fog" args={['#080d1a', 18, 72]} />
      <ambientLight intensity={0.42} color="#a6b8d0" />
      <directionalLight position={[-14, 22, 8]} intensity={1.3} color="#b8c8e2" castShadow />
      <pointLight position={[-14, 7, 1]} color="#698da5" intensity={1.4} distance={25} />
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[100, 100, 1, 1]} />
        <meshStandardMaterial color="#111d24" roughness={1} />
      </mesh>
      <mesh position={[0, -0.01, -16]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[3.5, 42]} />
        <meshStandardMaterial color="#192a2d" roughness={1} />
      </mesh>
      <mesh position={[0, 0.02, -17]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.7, 42]} />
        <meshStandardMaterial color="#273c3d" roughness={1} />
      </mesh>
      <mesh position={[-22, 13, -50]}>
        <sphereGeometry args={[5.5, 24, 24]} />
        <meshBasicMaterial color="#c8d6e2" />
      </mesh>
      <House />
      <Tower />
      <Fireflies />
      {TREES.map(([x, z, scale]) => <Tree key={`${x}-${z}`} x={x} z={z} scale={scale} />)}
      {ROCKS.map(([x, z, scale]) => <Rock key={`${x}-${z}`} x={x} z={z} scale={scale} />)}
    </>
  );
}

function PlayerAvatar({ player }: { player: MutableRefObject<THREE.Vector3> }) {
  const group = useRef<THREE.Group>(null);
  useFrame(() => {
    if (group.current) group.current.position.copy(player.current);
  });
  return (
    <group ref={group}>
      <mesh position={[0, 0.68, 0]} castShadow>
        <capsuleGeometry args={[0.32, 0.85, 5, 10]} />
        <meshStandardMaterial color="#657d82" roughness={0.7} />
      </mesh>
      <mesh position={[0, 1.32, 0]} castShadow>
        <sphereGeometry args={[0.29, 12, 8]} />
        <meshStandardMaterial color="#bcc8bf" roughness={0.8} />
      </mesh>
      <pointLight position={[0, 1.2, 0]} color="#89dae5" intensity={0.22} distance={3.2} />
    </group>
  );
}

function CameraRig({
  player,
  yaw,
  pitch,
}: {
  player: MutableRefObject<THREE.Vector3>;
  yaw: MutableRefObject<number>;
  pitch: MutableRefObject<number>;
}) {
  const { camera } = useThree();
  const desired = useMemo(() => new THREE.Vector3(), []);
  const target = useMemo(() => new THREE.Vector3(), []);
  useFrame((_, delta) => {
    const distance = 7.2;
    desired.set(Math.sin(yaw.current) * distance, 3.7 + pitch.current * 1.8, Math.cos(yaw.current) * distance).add(player.current);
    camera.position.lerp(desired, 1 - Math.pow(0.001, delta));
    target.copy(player.current).add(new THREE.Vector3(0, 1.05 + pitch.current * 0.4, 0));
    camera.lookAt(target);
  });
  return null;
}

function PlayerMovement({
  player,
  yaw,
  phase,
  storyStep,
  onLandmark,
}: {
  player: MutableRefObject<THREE.Vector3>;
  yaw: MutableRefObject<number>;
  phase: Phase;
  storyStep: number;
  onLandmark: (landmark: Landmark) => void;
}) {
  const [, get] = useKeyboardControls<Controls>();
  const lastNear = useRef<Landmark | null>(null);
  const move = useMemo(() => new THREE.Vector3(), []);
  const next = useMemo(() => new THREE.Vector3(), []);
  useFrame((_, delta) => {
    if (phase !== 'explore') return;
    const controls = get();
    move.set(
      Number(controls.right) - Number(controls.left),
      0,
      Number(controls.back) - Number(controls.forward),
    );
    if (move.lengthSq() > 0) {
      move.normalize().applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw.current);
      next.copy(player.current).addScaledVector(move, Math.min(delta, 0.05) * 5.3);
      next.x = THREE.MathUtils.clamp(next.x, -32, 32);
      next.z = THREE.MathUtils.clamp(next.z, -43, 12);
      const blocked = COLLIDERS.some((box) => Math.abs(next.x - box.x) < box.w / 2 + 0.55 && Math.abs(next.z - box.z) < box.d / 2 + 0.55);
      if (!blocked) player.current.copy(next);
    }
    const houseDistance = Math.hypot(player.current.x + 8, player.current.z + 11);
    const towerDistance = Math.hypot(player.current.x - 10, player.current.z + 27);
    const nearby = storyStep === 0 && houseDistance < 4.1 ? 'house' : storyStep === 1 && towerDistance < 4.6 ? 'tower' : null;
    if (nearby && nearby !== lastNear.current) {
      lastNear.current = nearby;
      onLandmark(nearby);
    }
  });
  return null;
}

function GameCanvas({
  player,
  yaw,
  pitch,
  phase,
  storyStep,
  onLandmark,
}: {
  player: MutableRefObject<THREE.Vector3>;
  yaw: MutableRefObject<number>;
  pitch: MutableRefObject<number>;
  phase: Phase;
  storyStep: number;
  onLandmark: (landmark: Landmark) => void;
}) {
  return (
    <Canvas
      shadows
      fallback={<WebglFallback />}
      camera={{ position: [0, 4, 15], fov: 54, near: 0.1, far: 100 }}
    >
      <ValleyWorld />
      <PlayerMovement player={player} yaw={yaw} phase={phase} storyStep={storyStep} onLandmark={onLandmark} />
      <PlayerAvatar player={player} />
      <CameraRig player={player} yaw={yaw} pitch={pitch} />
    </Canvas>
  );
}

function StoryOverlay({ phase, onContinue, onStart }: { phase: Phase; onContinue: () => void; onStart: () => void }) {
  if (phase === 'intro') {
    return (
      <div className="story-backdrop" data-testid="overlay-intro">
        <div className="story-card">
          <div className="eyebrow">A playable prologue · 01 / 03</div>
          <h1>Shadow<br />Valley</h1>
          <h3>Something is awake beyond the trees.</h3>
          <p>At the edge of the valley, a blue signal cuts through the dark. Follow it. The old house may remember why it is still shining.</p>
          <div className="meta"><span>Moonlit / 2:17 AM</span><span>Quiet country road</span></div>
          <button className="story-action" onClick={onStart} data-testid="button-start-exploration">Enter the valley</button>
        </div>
      </div>
    );
  }
  if (phase === 'house' || phase === 'tower') {
    const isHouse = phase === 'house';
    return (
      <div className="story-backdrop" data-testid={`overlay-${phase}`}>
        <div className="story-card">
          <div className="eyebrow">{isHouse ? 'The old house · 02 / 03' : 'The signal · 03 / 03'}</div>
          <h3>{isHouse ? 'A light behind the boards.' : 'It has been waiting for you.'}</h3>
          <p>{isHouse ? 'The door will not move, but the window is warm. Somewhere below the floorboards, a radio repeats three notes — the same three notes that drift from the tower.' : 'The crystal does not illuminate the valley. It maps it. For one breath, the trees arrange themselves into a path that was never there before.'}</p>
          <button className="story-action" onClick={onContinue} data-testid={`button-continue-${phase}`}>{isHouse ? 'Follow the signal' : 'Touch the crystal'}</button>
        </div>
      </div>
    );
  }
  if (phase === 'complete') {
    return (
      <div className="story-backdrop" data-testid="overlay-complete">
        <div className="story-card">
          <div className="completion-mark" aria-hidden="true" />
          <div className="eyebrow">End of prologue</div>
          <h3>The valley has noticed you.</h3>
          <p>Beyond the signal, the dark opens into somewhere deeper. This is where the story begins.</p>
          <div className="meta"><span>Signal found</span><span>Path revealed</span></div>
          <button className="story-action" onClick={onContinue} data-testid="button-return-to-valley">Return to the valley</button>
        </div>
      </div>
    );
  }
  return null;
}

function Home() {
  const [phase, setPhase] = useState<Phase>('intro');
  const [storyStep, setStoryStep] = useState(0);
  const [pointerLocked, setPointerLocked] = useState(false);
  const [webglAvailable, setWebglAvailable] = useState<boolean | null>(null);
  const [landmark, setLandmark] = useState<Landmark | null>(null);
  const player = useRef(new THREE.Vector3(0, 0, 8));
  const yaw = useRef(0);
  const pitch = useRef(-0.15);
  const viewportRef = useRef<HTMLDivElement>(null);
  const dragging = useRef(false);
  const previousPointer = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const onLockChange = () => setPointerLocked(document.pointerLockElement !== null);
    document.addEventListener('pointerlockchange', onLockChange);
    return () => document.removeEventListener('pointerlockchange', onLockChange);
  }, []);

  useEffect(() => {
    const probe = document.createElement('canvas');
    const context =
      probe.getContext('webgl2', { failIfMajorPerformanceCaveat: true }) ??
      probe.getContext('webgl', { failIfMajorPerformanceCaveat: true });
    setWebglAvailable(Boolean(context));
    const loseContext = context?.getExtension('WEBGL_lose_context');
    loseContext?.loseContext();
  }, []);

  const lockPointer = useCallback(() => {
    const canvas = viewportRef.current?.querySelector('canvas');
    if (canvas && document.pointerLockElement !== canvas) canvas.requestPointerLock?.();
  }, []);

  const start = useCallback(() => {
    setPhase('explore');
    lockPointer();
  }, [lockPointer]);

  const handleLandmark = useCallback((nextLandmark: Landmark) => {
    setLandmark(nextLandmark);
    setPhase(nextLandmark);
    document.exitPointerLock?.();
  }, []);

  const continueStory = useCallback(() => {
    if (phase === 'house') {
      setStoryStep(1);
      setPhase('explore');
      setLandmark(null);
      lockPointer();
    } else if (phase === 'tower') {
      setPhase('complete');
      setStoryStep(2);
      setLandmark(null);
      document.exitPointerLock?.();
    } else if (phase === 'complete') {
      setPhase('explore');
      lockPointer();
    }
  }, [lockPointer, phase]);

  const handlePointerDown = (event: PointerEvent<HTMLDivElement>) => {
    if (phase !== 'explore') return;
    dragging.current = true;
    previousPointer.current = { x: event.clientX, y: event.clientY };
    lockPointer();
  };
  const handlePointerMove = (event: PointerEvent<HTMLDivElement>) => {
    if (phase !== 'explore') return;
    const dx = document.pointerLockElement ? event.movementX : event.clientX - previousPointer.current.x;
    const dy = document.pointerLockElement ? event.movementY : event.clientY - previousPointer.current.y;
    if (!document.pointerLockElement && !dragging.current) return;
    yaw.current -= dx * 0.004;
    pitch.current = THREE.MathUtils.clamp(pitch.current - dy * 0.0025, -0.8, 0.45);
    previousPointer.current = { x: event.clientX, y: event.clientY };
  };
  const handlePointerUp = () => { dragging.current = false; };
  const objective = storyStep === 0 ? 'Find the old house' : storyStep === 1 ? 'Follow the blue signal' : 'The path is open';

  return (
    <KeyboardControls map={keyMap}>
      <main className="game-shell" aria-label="Shadow Valley playable prologue">
        <div
          ref={viewportRef}
          className="game-viewport"
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          data-testid="game-viewport"
        >
          {webglAvailable === true ? (
            <GameCanvas player={player} yaw={yaw} pitch={pitch} phase={phase} storyStep={storyStep} onLandmark={handleLandmark} />
          ) : phase === 'intro' ? null : webglAvailable === false ? (
            <WebglFallback />
          ) : (
            <div className="webgl-fallback" role="status" aria-label="Preparing the valley">
              <div className="webgl-fallback-kicker">Shadow Valley / tuning the signal</div>
              <h2>Preparing the valley</h2>
            </div>
          )}
        </div>
        <div className="grain" aria-hidden="true" />
        <div className="letterbox top" aria-hidden="true" />
        <div className="letterbox bottom" aria-hidden="true" />
        <div className="hud">
          <div className="hud-bar">
            <div className="wordmark">Shadow Valley<small>field recording 01</small></div>
            {phase !== 'intro' && (
              <div className="status-cluster">
                <div className="status-pill" data-testid="status-exploration"><span className={`status-dot ${storyStep === 2 ? 'warm' : ''}`} />{phase === 'complete' ? 'prologue complete' : 'exploration active'}</div>
              </div>
            )}
          </div>
          {phase === 'explore' && (
            <>
              <div className="control-note" data-testid="text-controls">
                <strong>{pointerLocked ? 'Look freely' : 'Click and drag to look'}</strong><br />
                <span>WASD / ARROWS</span> move through the valley
              </div>
              <div className="center-vignette" aria-hidden="true" />
              <div className="bottom-hud">
                <div className="objective" data-testid="text-objective">
                  <div className="eyebrow">Current thread</div>
                  <h2>{objective}</h2>
                  <p>{storyStep === 0 ? 'A single lit window waits beyond the path.' : 'The crystal is somewhere past the pines.'}</p>
                </div>
                <div className="progress-track" aria-label={`Story progress ${storyStep + 1} of 3`}>
                  <span>Valley log</span><span className="progress-line"><i style={{ width: `${Math.max(33, storyStep * 33)}%` }} /></span><span>0{Math.min(storyStep + 1, 3)} / 03</span>
                </div>
              </div>
            </>
          )}
        </div>
        {phase !== 'explore' && <StoryOverlay phase={phase} onContinue={continueStory} onStart={start} />}
        {phase === 'explore' && !pointerLocked && (
          <div className="interaction-card" style={{ position: 'absolute', right: 'clamp(1rem, 5vw, 4.8rem)', bottom: 'clamp(1rem, 3vw, 2.8rem)', zIndex: 7 }} data-testid="pointer-help">
            <h3>Mouse look is available</h3>
            <p>Click the scene to capture the pointer. If your browser declines, drag across the scene instead.</p>
          </div>
        )}
        <span className="sr-only" aria-live="polite" data-testid="text-landmark-state">
          {landmark ? `${landmark} reached` : ''}
        </span>
      </main>
    </KeyboardControls>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;