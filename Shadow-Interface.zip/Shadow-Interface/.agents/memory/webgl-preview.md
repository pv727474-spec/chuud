---
name: WebGL preview fallback
description: Browser preview environments may not expose a WebGL context even when the game is otherwise valid.
---

Guard WebGL canvas mounting with a browser capability probe and render a readable fallback when no context is available.

**Why:** The managed preview can run without GPU/WebGL support, and mounting React Three Fiber directly causes a runtime overlay before the app can show its own fallback.

**How to apply:** For future 3D browser artifacts, probe `webgl2`/`webgl` before mounting the renderer; keep the actual game path intact for hardware-accelerated browsers.